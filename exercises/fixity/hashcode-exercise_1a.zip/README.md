# The Hashcode Manifest Exercise
## Aka "Something has changed. Find out what"

The system administrators of ACME archives generate MD5 hashcode manifest files
during ingest. So everything stored in the archive is documented in a way that
any change is automatically detected.

One folder in the archive is said to be haunted!

Whenever the integrity/fixity-check analysis its current state, something has
changed. O.O

The sysadmins have saved the generated manifests of the last 6 checks that
caused the integrity checks to raise a flag - throw an error. 

Compare each one of these manifest files to the "should be" reference version
`MD5SUMS-reference.md5` and try to figure out what happened this time, and if
there is anything to do about it?



Peter B. (pb@ArkThis.com)
2021-11-21
(Solutions below - attention: Spoilers! :P)






























# Solution - SPOILER ALERT!

> =====================================================
> Only read this, if you want to know the answers :)
> =====================================================

  1. file renamed
  2. file overwritten with other file
  3. file modified (data corruption or on purpose?)
  4. data-error in hashcode manifest
  5. file added
  6. file removed
